'use client';

import React, { useState, useEffect } from 'react';
import { Droplet, Plus, RefreshCw, Check } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { getWaterForDate, saveWaterForDate } from '../services/dietStorage';

interface WaterTrackerProps {
    currentDateKey?: string;
}

export default function WaterTracker({ currentDateKey }: WaterTrackerProps) {
    const { userProfile } = useAuth();
    
    const goal = userProfile?.waterGoalMl || 3000;
    const dateKey = currentDateKey || new Date().toISOString().slice(0, 10);
    const [waterMl, setWaterMl] = useState<number>(1200);

    // Sync water state whenever currentDateKey changes
    useEffect(() => {
        setWaterMl(getWaterForDate(dateKey));
    }, [dateKey]);

    const addWater = (amount: number) => {
        setWaterMl((prev) => {
            const next = Math.min(goal + 1000, prev + amount);
            saveWaterForDate(dateKey, next);
            return next;
        });
    };

    const resetWater = () => {
        if (confirm('Reset water intake for this date?')) {
            setWaterMl(0);
            saveWaterForDate(dateKey, 0);
        }
    };

    const percentage = Math.min(100, Math.round((waterMl / goal) * 100));

    return (
        <div className="bg-white border border-gray-100 border-gray-200 rounded-3xl p-5 shadow-sm transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-blue-50/40 via-white/50 to-cyan-50/40">
            <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-blue-500/10 flex items-center justify-center border border-blue-500/20 shadow-sm relative overflow-hidden flex-shrink-0">
                    <div 
                        className="absolute bottom-0 left-0 right-0 bg-blue-400/30 transition-all duration-700 ease-out"
                        style={{ height: `${percentage}%` }}
                    />
                    <Droplet size={26} className="text-blue-600 relative z-10 drop-shadow-sm" />
                </div>
                <div>
                    <div className="flex items-center gap-2">
                        <h3 className="text-sm font-black text-gray-900 drop-shadow-sm">Hydration Tracker</h3>
                        {percentage >= 100 && (
                            <span className="bg-emerald-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full flex items-center gap-1 shadow-sm">
                                <Check size={12} strokeWidth={3} /> Goal Met!
                            </span>
                        )}
                    </div>
                    <p className="text-xs text-gray-600 font-bold mt-0.5">
                        {waterMl} ml / {goal} ml consumed ({percentage}%)
                    </p>
                </div>
            </div>

            <div className="flex items-center gap-2 w-full md:w-auto">
                <div className="flex-1 md:w-36 bg-gray-100 h-2.5 rounded-full overflow-hidden shadow-inner border border-gray-100 dark:border-slate-800">
                    <div 
                        className="bg-gradient-to-r from-blue-400 to-cyan-400 h-full rounded-full transition-all duration-700 ease-out shadow-[0_0_10px_rgba(96,165,250,0.6)]" 
                        style={{ width: `${percentage}%` }} 
                    />
                </div>

                <div className="flex items-center gap-1.5 flex-shrink-0">
                    <button
                        id="tour-add-water"
                        onClick={() => addWater(250)}
                        className="flex items-center gap-1 bg-blue-500 hover:bg-blue-600 text-white px-3 py-1.5 rounded-xl text-xs font-bold transition-all shadow-sm border border-white/20 btn-press relative z-[110]"
                        title="Add 1 Glass (250 ml)"
                    >
                        <Plus size={14} /> 250ml
                    </button>
                    <button
                        onClick={() => addWater(500)}
                        className="flex items-center gap-1 bg-cyan-600 hover:bg-cyan-700 text-white px-3 py-1.5 rounded-xl text-xs font-bold transition-all shadow-sm border border-white/20 btn-press"
                        title="Add 1 Bottle (500 ml)"
                    >
                        <Plus size={14} /> 500ml
                    </button>
                    <button
                        onClick={resetWater}
                        className="p-1.5 rounded-xl hover:bg-red-50 text-gray-400 hover:text-red-600 transition-colors btn-press"
                        title="Reset water intake"
                    >
                        <RefreshCw size={14} />
                    </button>
                </div>
            </div>
        </div>
    );
}
